$(function() {
  $('body').scrollspy({ offset: 40 });
})
