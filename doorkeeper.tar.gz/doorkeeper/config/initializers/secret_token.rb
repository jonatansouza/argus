# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DoorkeeperProvider::Application.config.secret_token = '0aae5b82530809fc1825e8383bff5b720a49e3cbe417f4fd1d3c5804ed75fbc91cc86d00257c931eff4666f40e7536154151565a16da52b8adec77a887670be2'
